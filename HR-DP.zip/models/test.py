
import torch
a = torch.tensor(torch.ones(2,5,2,3))
a = torch.tensor([1,3,5,2,4,6],dtype=torch.float32).view(1,1,2,3)
b = torch.tensor([1,2,3],dtype=torch.float32).view(1,1,1,3)

print(torch.tanh(b))
print(torch.tanh(a))