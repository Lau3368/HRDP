
import numpy as np
import seaborn as sns
import sys
#from rel_att import RelAttention
from models.rel_att import RelAttention
attention = RelAttention(dropout=0.0)
from models.attention_test import MultiHeadAttention
# from my_model.bert_em import BERT_EM
sys.path.append('..')
import utils
import torch
from torch import nn
from torch.nn import functional as F
#multihead_attn = nn.MultiheadAttention(768, 1)
class RelReProto(utils.framework.FewShotREModel):
    def __init__(self, sentence_encoder, hidden_size, max_len):
        utils.framework.FewShotREModel.__init__(self, sentence_encoder)
        self.hidden_size = hidden_size
        self.max_len = max_len
        self.attention = MultiHeadAttention()
        self.fc1 = nn.Linear(hidden_size, 4 *hidden_size)
        self.fc3 = nn.Linear(4 * hidden_size, hidden_size) 
    def __dist__(self, x, y, dim):
        return -(torch.pow(x - y, 2)).sum(dim)

    def __batch_dist__(self, S, Q):
        return self.__dist__(S.unsqueeze(1), Q.unsqueeze(2), 3)

    def forward(self, support, query, rel_text, N, K, total_Q, is_eval=True):
        support_entity, support_sentence,support_s = self.sentence_encoder(support)  # (B * N * K, 2D), (B * N * K, L, D)
        query_glo, query_loc,query_sentence = self.sentence_encoder(query)  # (B * total_Q, 2D), (B * total_Q, L, D)
        rel_text_sentence, rel_sentence = self.sentence_encoder(rel_text, cat=False)  # (B * N, D), (B * N, L, D)
        support_entity = support_entity.view(-1, N, K, self.hidden_size * 2)
        query_glo = query_glo.view(-1, total_Q, self.hidden_size * 2)
        B = support_entity.shape[0]
        support_sentence_ = support_sentence
        query_loc_ = query_loc
        support_s = support_s.view(B,N,K,self.hidden_size)
        query_sentence = query_sentence.view(B,total_Q,self.hidden_size)
        support_loc_2 = support_sentence_.view(B*N,K,self.max_len,self.hidden_size)
        support_loc2 = support_sentence_.view(B,N,K,self.max_len,self.hidden_size)
        query_loc2 = query_loc.view(B,total_Q,self.max_len,self.hidden_size)
        rel_sentence_ = rel_sentence.view(B*N,1,self.max_len,self.hidden_size)
        rel_sentence_s = rel_sentence.unsqueeze(1).expand(-1, K, -1, -1).contiguous().view(B * N * K, -1, self.hidden_size)  
        support_sentence,_ = attention(support_sentence,rel_sentence_s,support_sentence)
        support_sentence = support_sentence.view(B, N, K,self.hidden_size)
        rel_sentence,_ = attention(support_sentence_,rel_sentence_s,rel_sentence_s)
        rel_sentence = rel_sentence.view(B, N, K, self.hidden_size)
        score_3 =rel_sentence*support_sentence
        score_3 = torch.mean(score_3,-1).view(B,N,K)
        score_3 = (score_3-torch.min(score_3))/(torch.max(score_3) - torch.min(score_3))
        score_3 = torch.softmax(torch.tanh(score_3), dim=-1)
        query_loc,_ = attention(query_loc,query_loc,query_loc)
        query_loc = query_loc.view(B, total_Q,self.hidden_size)  # (B, total_Q, D)
        proto_entity_temp = torch.mean(support_entity,2).unsqueeze(2)
        logits_weight = proto_entity_temp*support_entity
        weight_entity = torch.mean(logits_weight,-1)
        score_entity = (weight_entity-torch.min(weight_entity))/(torch.max(weight_entity) - torch.min(weight_entity))
        score_entity = torch.softmax(torch.tanh(weight_entity), dim=-1)
        proto_entity = torch.sum(score_entity.unsqueeze(-1)*support_entity, 2)
        proto_loc = torch.sum(score_3.unsqueeze(-1)*support_sentence, 2)
        proto_cat = torch.cat((proto_loc,proto_entity),dim=2)
        query_cat = torch.cat((query_loc,query_glo),dim=2)
        logits = self.__batch_dist__(proto_cat, query_cat)  # (B, total_Q, N)
        minn, _ = logits.min(-1)
        logits = torch.cat([logits, minn.unsqueeze(2) - 1], 2)  # (B, total_Q, N + 1)
        _, pred = torch.max(logits.view(-1, N + 1), 1)

        return logits, pred