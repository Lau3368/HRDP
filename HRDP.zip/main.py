import os
from utils.data_loader import get_loader
from utils.framework import FewShotREFramework
from utils.sentence_encoder import BERTSentenceEncoder
import models
from models.HR_Dproto import RelReProto
import sys
import torch
from torch import optim, nn
import numpy as np
import json
import argparse
import torch
import random
import time
import threading
def main(parser):
    opt = parser.parse_args()
    random.seed(opt.seed)
    np.random.seed(opt.seed)
    torch.manual_seed(opt.seed)
    torch.cuda.manual_seed_all(opt.seed)
    trainN = opt.trainN
    N = opt.N
    K = opt.K
    Q = opt.Q
    batch_size = opt.batch_size
    model_name = opt.model
    encoder_name = opt.encoder
    max_length = opt.max_length
    sentence_encoder = BERTSentenceEncoder(opt.pretrain_ckpt, max_length, path=opt.path)
    if not opt.test_gen:
        train_data_loader = get_loader(opt.train, opt.pid2name, sentence_encoder,
                    N=trainN, K=K, Q=Q, batch_size=batch_size, ispubmed=opt.ispubmed, root=opt.root)
        val_data_loader = get_loader(opt.val, opt.pid2name, sentence_encoder,
                    N=N, K=K, Q=Q, batch_size=batch_size, ispubmed=opt.ispubmed, root=opt.root)
        test_data_loader=None
    else:
        test_data_loader=None
        train_data_loader=None
        val_data_loader=None
    framework = FewShotREFramework(train_data_loader, val_data_loader, test_data_loader)

    model = RelReProto(sentence_encoder, hidden_size=opt.hidden_size, max_len=max_length)
    if torch.cuda.is_available():
        model.cuda()
    
    import threading 
    event = threading.Event()
    if opt.test_gen:
        framework.test(model,opt,sentence_encoder)

    # model save path
    if not os.path.exists(opt.checkpoints_path):
        os.mkdir(opt.checkpoints_path)

    prefix = '-'.join([model_name, encoder_name, opt.train, opt.val, str(N), str(K)])
    ckpt = '{}/{}.pth.tar'.format(opt.checkpoints_path,prefix)
    if opt.save_ckpt:
        ckpt = opt.save_ckpt

    if not opt.only_test:
        framework.train(model, prefix, trainN, N, K, Q, learning_rate=opt.lr, weight_decay=opt.weight_decay,
                lamda=opt.lamda, train_iter=opt.train_iter, val_iter=opt.val_iter,
                load_ckpt=opt.load_ckpt, save_ckpt=ckpt, val_step=opt.val_step, grad_iter=opt.grad_iter)
    else:
        ckpt = opt.load_ckpt


if __name__ == "__main__":
    train_config = json.load(open(f"./train_config.json"))
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', default='./data',
                        help='file root')
    parser.add_argument('--train', default='train_wiki',
                        help='train file')
    parser.add_argument('--val', default='val_wiki',
                        help='val file')
    parser.add_argument('--test', default="",
                        help='test file')
    parser.add_argument('--ispubmed', default=False, type=bool)
    parser.add_argument('--pid2name', default='pid2name')
    parser.add_argument('--trainN', default=10, type=int,
                        help='N in train')
    parser.add_argument('--N', default=10, type=int,
                        help='N way')
    parser.add_argument('--K', default=5, type=int,
                        help='K shot')
    parser.add_argument('--Q', default=1, type=int,
                        help='Num of query per class')
    parser.add_argument('--batch_size', default=4, type=int,
                        help='batch size')
    parser.add_argument('--train_iter', default=10000, type=int,
                        help='num of iters in training')
    parser.add_argument('--val_iter', default=1000, type=int,
                        help='num of iters in validation')
    parser.add_argument('--test_iter', default=1000, type=int,
                        help='num of iters in testing')
    parser.add_argument('--val_step', default=1000, type=int,
                        help='val after training how many iters')
    parser.add_argument('--model', default='rrproto',
                        help='model name')
    parser.add_argument('--encoder', default='bert',
                        help='encoder: bert')
    parser.add_argument('--max_length', default=128, type=int,
                        help='max length')
    parser.add_argument('--lr', default=2e-5, type=float,
                        help='learning rate')
    parser.add_argument('--weight_decay', default=0.01, type=float,
                        help='weight decay')
    parser.add_argument('--lamda', default=1, type=float,
                        help='loss combination')
    parser.add_argument('--grad_iter', default=2, type=int)
    parser.add_argument('--optim', default='adamw',
                        help='sgd / adam / adamw')
    parser.add_argument('--hidden_size', default=768, type=int,
                        help='hidden size')
    parser.add_argument('--save_ckpt', default=None,
                        help='save ckpt')
    parser.add_argument('--only_test', default=False,
                        help='only test')
    parser.add_argument('--pretrain_ckpt', default=train_config["original_base_model"],
                        help='bert / roberta pre-trained checkpoint')
    parser.add_argument('--seed', default=0, type=int,
                        help='seed')
    parser.add_argument('--path', default=None,
                        help='path to ckpt')
    parser.add_argument('--test_gen', action='store_true',
                    help='')
    parser.add_argument('--load_ckpt', default="",
                        help='load ckpt')
    parser.add_argument('--test_data', default="test_wiki_input-5-1-id.json",
                    help='')
    parser.add_argument('--save_pred', default="",
                    help='')
    parser.add_argument('--data_path', default="./data/",
                    help='')
    parser.add_argument('--pred_data_path', default="./data/pred_out/",
                    help='')
    parser.add_argument('--checkpoints_path', default="checkpoints")
    print(parser.parse_args())


    main(parser)

