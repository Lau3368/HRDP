
import torch
import torch.nn as nn
import  math
def calculate_distance_for(x,y):
    batch_size=len(x)
    row=len(x[0])
    colum=len(y[0])
    m = torch.zeros(batch_size,row, colum).to(torch.device)
    for i in range(batch_size):
        for j in range(row):
            for k in range(colum):
            # torch.cosine_similarity(x[i],x[j])
                d2=torch.dist(x[i][j]  ,y[i][k], p=2)
                m[i][j][k]=d2
    return m
class RelAttention(nn.Module):
    def __init__(self, dropout, **kwargs):
        super(RelAttention, self).__init__(**kwargs)
        self.dropout = nn.Dropout(dropout)
    def forward(self, queries, keys, values):
    	
        d = queries.shape[-1]
        scores_ = (torch.div((torch.bmm(queries, keys.transpose(1,2))) ,math.sqrt(d)))
        scores,_ = scores_.max(-1)
        self.attention_weights = torch.softmax(torch.tanh(scores), dim=1).unsqueeze(-1)
        result = torch.sum(self.attention_weights*values,dim=1)
        return result ,scores_
class NOTRelAttention(nn.Module):
    def __init__(self, dropout, **kwargs):
        super(RelAttention, self).__init__(**kwargs)
        self.dropout = nn.Dropout(dropout)
    def forward(self, queries, keys, values):
        d = queries.shape[-1]
        scores_ = (torch.div((torch.bmm(queries, keys.transpose(1,2))) ,math.sqrt(d)))
        scores,_ = scores_.max(-1)
        self.attention_weights = torch.softmax(torch.tanh(scores), dim=1).unsqueeze(-1)
        result = torch.sum(self.attention_weights*values,dim=1)
        return result ,scores_