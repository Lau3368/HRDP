
import numpy as np
import seaborn as sns
import sys
#from rel_att import RelAttention
from models.rel_att import RelAttention
attention = RelAttention(dropout=0.0)
from models.attention_test import MultiHeadAttention
# from my_model.bert_em import BERT_EM
sys.path.append('..')
import utils
import torch
from torch import nn
from torch.nn import functional as F

class RelReProto(utils.framework.FewShotREModel):
    def __init__(self, sentence_encoder, hidden_size, max_len):
        utils.framework.FewShotREModel.__init__(self, sentence_encoder)
        self.hidden_size = hidden_size
        self.max_len = max_len
        self.attention = MultiHeadAttention()
        self.fc1 = nn.Linear(hidden_size, 4 *hidden_size)
        self.fc3 = nn.Linear(4 * hidden_size, hidden_size) 
    def __dist__(self, x, y, dim):
        return -(torch.pow(x - y, 2)).sum(dim)

    def __batch_dist__(self, S, Q):
        return self.__dist__(S.unsqueeze(1), Q.unsqueeze(2), 3)

    def forward(self, support, query, rel_text, N, K, total_Q, is_eval=True):
        support_entity, support_sentence,_ = self.sentence_encoder(support)
        query_1, query_2,_ = self.sentence_encoder(query)
        _, rel_sentence = self.sentence_encoder(rel_text, cat=False)
        support_entity = support_entity.view(-1, N, K, self.hidden_size * 2)
        query_1 = query_1.view(-1, total_Q, self.hidden_size * 2)
        B = support_entity.shape[0]
        support_sentence_ = support_sentence
        rel_sentence_s = rel_sentence.unsqueeze(1).expand(-1, K, -1, -1).contiguous().view(B * N * K, -1, self.hidden_size)  
        support_sentence,_ = attention(support_sentence,rel_sentence_s,support_sentence)
        support_sentence = support_sentence.view(B, N, K,self.hidden_size)
        rel_sentence,_ = attention(support_sentence_,rel_sentence_s,rel_sentence_s)
        rel_sentence = rel_sentence.view(B, N, K, self.hidden_size)
        score = torch.mean(rel_sentence*support_sentence,-1).view(B,N,K)
        score = (score-torch.min(score))/(torch.max(score) - torch.min(score))
        score = torch.softmax(torch.tanh(score), dim=-1)
        query_2,_ = attention(query_2,query_2,query_2)
        query_2 = query_2.view(B, total_Q,self.hidden_size)
        proto_e_temp = torch.mean(support_entity,2).unsqueeze(2)
        logits_weight = proto_e_temp*support_entity
        weight_entity = torch.mean(logits_weight,-1)
        score_entity = torch.softmax(torch.tanh(weight_entity), dim=-1)
        proto_e = torch.sum(score_entity.unsqueeze(-1)*support_entity, 2)
        proto_r = torch.sum(score.unsqueeze(-1)*support_sentence, 2)
        proto_cat = torch.cat((proto_r,proto_e),dim=2)
        query_cat = torch.cat((query_2,query_1),dim=2)
        logits = self.__batch_dist__(proto_cat, query_cat)
        minn, _ = logits.min(-1)
        logits = torch.cat([logits, minn.unsqueeze(2) - 1], 2)
        _, pred = torch.max(logits.view(-1, N + 1), 1)

        return logits, pred